﻿Module Funciones
'Public oHbmTrade As ZTRADE
Public cPeso As String = String.Empty

    Public Function TxtNum(ByVal uuVar As Object) As Object
        Dim x As Integer
        Dim cChr As String
        Dim cValor As String
        If String.IsNullOrEmpty(uuVar) Then
            TxtNum = 0
        Else
            uuVar = Trim(uuVar)
            cValor = ""
            For x = 1 To Len(uuVar)
                cChr = Mid(uuVar, x, 1)
                If InStr("0123456789.", cChr, CompareMethod.Text) > 0 Then
                    cValor = cValor & cChr
                End If
            Next
            TxtNum = Val(cValor)
        End If
    End Function
End Module
